# Spreadsheet QA checklist

- Data lineage: record source, transformation, snapshot date, units, and missing-value conventions.
- Use imported data as **text**, not as executable formulas. The importer escapes formula-like CSV strings; JSON `formulas` is explicitly trusted user-supplied workbook code.
- Formula validation: `openpyxl` writes formulas but **does not calculate them**. Open in Excel or LibreOffice to recalculate and re-save before using cached results.
- Review hidden sheets, external links, error cells and merges. Audit flags major categories but is not a complete security scan.
- Avoid silent deletion of formulas, data validation, named ranges, or charts when round-tripping complex external workbooks.
- Make changes on a copy; keep snapshots and compare with the previous version.
- Confirm date parsing and decimal separators in the intended locale.
