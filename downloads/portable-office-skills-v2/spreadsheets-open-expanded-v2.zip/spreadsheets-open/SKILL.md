---
name: spreadsheets-open
description: Original XLSX/CSV workflow: create multi-sheet workbooks with explicit formulas/charts/formatting, safely import CSV, export sheets, audit formulas and links, compare workbook cell values.
---

# Spreadsheets Open — Workbook Engineering

Use for independently created Excel workbooks or inspection of supplied ones. **Not the platform's proprietary spreadsheet runtime**; formulas are stored but not calculated by `openpyxl`.

## Workflow

1. Identify source data types and whether calculations are desired.
2. For external CSV, use `import-csv` (escapes formula-like strings). For structured workbooks, use `build` JSON.
3. Audit formulas, external links, hidden sheets and spreadsheet error values.
4. Open in Excel/LibreOffice for formula recalculation; inspect cached values if needed.
5. Export or compare versions; record whether values were cached or computed.

## CLI

```bash
python skills/spreadsheets-open/scripts/sheets_cli.py import-csv input.csv output/data.xlsx --sheet Data
python skills/spreadsheets-open/scripts/sheets_cli.py build examples/workbook.json output/model.xlsx
python skills/spreadsheets-open/scripts/sheets_cli.py inspect output/model.xlsx
python skills/spreadsheets-open/scripts/sheets_cli.py audit output/model.xlsx
python skills/spreadsheets-open/scripts/sheets_cli.py export-csv output/model.xlsx output/table.csv --sheet Revenue
python skills/spreadsheets-open/scripts/sheets_cli.py compare old.xlsx new.xlsx --limit 200
```

## Specification

`examples/workbook.json` provides `sheets` containing `name`, `rows`, `formulas` map (`"D2": "=B2*C2"`), optional `formats`, `fills`, `header`, `freeze`, and `charts` with `type`, `title`, `category_col`, `value_col`, `anchor`.

**Security:** untrusted CSV strings beginning with `=`, `+`, `-`, or `@` are escaped to reduce spreadsheet formula injection. Explicit formula mappings are trusted code input and should only be authored by the user.

## Caveats

`openpyxl` never evaluates formulas. Excel/LibreOffice may recompute them on opening, but exported cached values can be empty. Do not infer a financial result from an uncalculated workbook. The audit's external-link check is partial. Read `references/sheets-quality.md`.

## Dependencies

`openpyxl>=3.1,<4`.
