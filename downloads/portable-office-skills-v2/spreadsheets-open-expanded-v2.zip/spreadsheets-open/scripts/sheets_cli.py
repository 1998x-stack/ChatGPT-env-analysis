#!/usr/bin/env python3
"""Open spreadsheet automation: CSV, structured workbooks, formulas, charts, audit."""
import argparse
import csv
import json
from pathlib import Path


def esc_csv(s):
    """Treat imported CSV fields as text, not executable workbook formulas."""
    return "'" + s if isinstance(s, str) and s.lstrip().startswith(("=", "+", "-", "@")) else s


def parent(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def clean_sheet_name(name):
    s = str(name)
    if not 1 <= len(s) <= 31 or any(c in s for c in "[]:*?/\\"):
        raise ValueError(f"Illegal Excel worksheet name: {s!r}")
    return s


def style_header(ws):
    from openpyxl.styles import Font, PatternFill, Alignment
    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor="253A52")
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.row_dimensions[1].height = 28
    ws.freeze_panes = "A2"
    if ws.max_column > 0:
        ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        values = list(col)
        if not values:
            continue
        width = min(50, max(12, max(len(str(c.value if c.value is not None else "")) for c in values[:300]) + 2))
        ws.column_dimensions[values[0].column_letter].width = width


def import_csv(args):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    ws.title = clean_sheet_name(args.sheet)
    with args.input.open(encoding="utf-8-sig", newline="") as f:
        for row in csv.reader(f):
            ws.append([esc_csv(x) for x in row])
    if ws.max_row:
        style_header(ws)
    wb.save(parent(args.output))
    print(f"Imported {args.input} to {args.output} ({ws.max_row} rows)")


def chart_for_sheet(ws, desc):
    from openpyxl.chart import BarChart, LineChart, Reference
    from openpyxl.utils.cell import column_index_from_string
    typ = desc.get("type", "bar")
    if typ not in ("bar", "line"):
        raise ValueError("chart.type must be bar or line")
    chart = BarChart() if typ == "bar" else LineChart()
    chart.title = str(desc.get("title", ""))
    val_col = int(desc.get("value_col", 2))
    cat_col = int(desc.get("category_col", 1))
    if not 1 <= val_col <= ws.max_column or not 1 <= cat_col <= ws.max_column:
        raise ValueError("chart column index out of range")
    if ws.max_row < 2:
        raise ValueError("charts need a header and at least one data row")
    data = Reference(ws, min_col=val_col, min_row=1, max_row=ws.max_row)
    categories = Reference(ws, min_col=cat_col, min_row=2, max_row=ws.max_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)
    chart.width = 18; chart.height = 9
    ws.add_chart(chart, str(desc.get("anchor", "E3")))


def build(args):
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment
    spec = json.loads(args.input.read_text(encoding="utf-8"))
    sheets = spec.get("sheets") if isinstance(spec, dict) else None
    if not isinstance(sheets, list) or not sheets:
        raise ValueError('JSON must have a nonempty "sheets" array')
    wb = Workbook()
    wb.remove(wb.active)
    for sheet in sheets:
        if not isinstance(sheet, dict):
            raise ValueError("Each sheet must be an object")
        ws = wb.create_sheet(clean_sheet_name(sheet["name"]))
        rows = sheet.get("rows", [])
        if not isinstance(rows, list):
            raise ValueError("rows must be an array")
        for row in rows:
            if not isinstance(row, list):
                raise ValueError("each row must be an array")
            ws.append([cell if cell is None or isinstance(cell, (str, int, float, bool)) else str(cell) for cell in row])
        # An explicit formulas mapping is the only place executable spreadsheet formula code is accepted.
        for addr, expr in sheet.get("formulas", {}).items():
            if not isinstance(expr, str) or not expr.startswith("="):
                raise ValueError(f"Formula for {addr} must start with '='")
            ws[addr] = expr
        for addr, fmt in sheet.get("formats", {}).items():
            ws[addr].number_format = str(fmt)
        if sheet.get("header", True) and ws.max_row:
            style_header(ws)
        if sheet.get("freeze"):
            ws.freeze_panes = str(sheet["freeze"])
        for addr, rule in sheet.get("fills", {}).items():
            ws[addr].fill = PatternFill("solid", fgColor=str(rule).lstrip("#"))
        for chart in sheet.get("charts", []):
            chart_for_sheet(ws, chart)
    wb.calculation.fullCalcOnLoad = True
    wb.calculation.forceFullCalc = True
    wb.save(parent(args.output))
    print(f"Created {args.output} with {len(wb.worksheets)} sheets")


def inspect(args):
    from openpyxl import load_workbook
    wb = load_workbook(args.input, read_only=True, data_only=False)
    result = {"sheet_count": len(wb.sheetnames), "sheets": []}
    for ws in wb:
        result["sheets"].append({"name": ws.title, "rows": ws.max_row, "columns": ws.max_column, "state": ws.sheet_state})
    wb.close()
    print(json.dumps(result, indent=2, ensure_ascii=False))


def export_csv(args):
    from openpyxl import load_workbook
    wb = load_workbook(args.input, read_only=True, data_only=args.values)
    try:
        sheet = args.sheet or wb.sheetnames[0]
        if sheet not in wb.sheetnames:
            raise ValueError(f"Unknown sheet: {sheet}")
        with parent(args.output).open("w", newline="", encoding="utf-8-sig") as out:
            writer = csv.writer(out)
            for row in wb[sheet].values:
                writer.writerow([v if v is not None else "" for v in row])
        print(f"Exported {sheet} to {args.output}")
    finally:
        wb.close()


def audit(args):
    from openpyxl import load_workbook
    wb = load_workbook(args.input, data_only=False, read_only=False, keep_links=True)
    result = {"sheets": len(wb.sheetnames), "formulas": 0, "hidden_sheets": [], "errors": [], "external_links": len(wb._external_links), "charts": 0, "images": 0, "warnings": []}
    for ws in wb:
        if ws.sheet_state != "visible":
            result["hidden_sheets"].append(ws.title)
        result["charts"] += len(ws._charts)
        result["images"] += len(ws._images)
        for row in ws:
            for c in row:
                if c.data_type == "f":
                    result["formulas"] += 1
                elif c.data_type == "e":
                    result["errors"].append({"sheet": ws.title, "cell": c.coordinate, "value": c.value})
    if result["formulas"]:
        result["warnings"].append("Formula values may be unevaluated: openpyxl does not calculate formulas")
    if result["external_links"]:
        result["warnings"].append("Workbook contains links to external documents; review before opening")
    if result["hidden_sheets"]:
        result["warnings"].append("Workbook has hidden sheets")
    wb.close()
    print(json.dumps(result, indent=2, ensure_ascii=False))


def compare(args):
    from openpyxl import load_workbook
    left = load_workbook(args.old, read_only=True, data_only=False)
    right = load_workbook(args.new, read_only=True, data_only=False)
    report = {"added_sheets": sorted(set(right.sheetnames) - set(left.sheetnames)), "removed_sheets": sorted(set(left.sheetnames) - set(right.sheetnames)), "changed_cells": [], "truncated": False}
    try:
        for name in sorted(set(right.sheetnames) & set(left.sheetnames)):
            a, b = left[name], right[name]
            for row in range(1, max(a.max_row, b.max_row) + 1):
                for col in range(1, max(a.max_column, b.max_column) + 1):
                    v1, v2 = a.cell(row, col).value, b.cell(row, col).value
                    if v1 != v2:
                        report["changed_cells"].append({"sheet": name, "cell": b.cell(row, col).coordinate, "old": v1, "new": v2})
                        if len(report["changed_cells"]) >= args.limit:
                            report["truncated"] = True
                            print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
                            return
        print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    finally:
        left.close(); right.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    a = sub.add_parser("import-csv"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.add_argument("--sheet", default="Data"); a.set_defaults(fn=import_csv)
    a = sub.add_parser("build"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=build)
    a = sub.add_parser("inspect"); a.add_argument("input", type=Path); a.set_defaults(fn=inspect)
    a = sub.add_parser("export-csv"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.add_argument("--sheet"); a.add_argument("--values", action="store_true", help="Export cached values instead of formulas"); a.set_defaults(fn=export_csv)
    a = sub.add_parser("audit"); a.add_argument("input", type=Path); a.set_defaults(fn=audit)
    a = sub.add_parser("compare"); a.add_argument("old", type=Path); a.add_argument("new", type=Path); a.add_argument("--limit", type=int, default=200); a.set_defaults(fn=compare)
    args = ap.parse_args()
    try:
        args.fn(args)
    except (ValueError, OSError, KeyError) as exc:
        ap.exit(2, f"Error: {exc}\n")

if __name__ == "__main__":
    main()
