# PDF QA checklist

- `inspect`: compare page counts before/after transformations.
- `text`: check whether extraction returns meaningful text; scans may be image-only.
- `render`: rasterize and visually inspect every affected page.
- `redact-text`: verify matching text is absent from extracted text, search result and rasterized output. Also inspect images, objects, annotations, metadata and embedded files. This is not a full secure-redaction solution.
- `clean-metadata`: only touches common metadata; it does not remove all potentially sensitive content.
- `merge`: inspect page orientation, bookmarks, annotation changes and document origin.
- Do not alter third-party copyrighted documents for redistribution without authorization.
