---
name: pdf-open
description: Independently authored PDF workflow to inspect, merge, split, extract text, rotate, render previews, apply basic watermarks, remove matching text via true redaction annotations, and minimize metadata.
---

# PDF Open — Portable PDF Processing

Use this Skill for local PDF transformations that can be validated with PyMuPDF. This is **not** a copy or full reimplementation of any proprietary PDF Skill.

## Workflow

1. Record source page count, encryption and metadata via `inspect`.
2. Choose transform: `merge`, `pages`, `split`, `rotate`, `render`, `watermark`, `redact-text`, `clean-metadata`, `from-text` (ASCII-only).
3. Verify output count/content; for redaction, verify text no longer matches and manually inspect rasterized pages plus hidden metadata.
4. Warn when source is a scan: text extraction and `redact-text` cannot remove content that appears only as pixels.

## Commands

```bash
python skills/pdf-open/scripts/pdf_cli.py inspect input.pdf
python skills/pdf-open/scripts/pdf_cli.py text input.pdf --output output.txt
python skills/pdf-open/scripts/pdf_cli.py merge joined.pdf a.pdf b.pdf
python skills/pdf-open/scripts/pdf_cli.py pages input.pdf pages3-5.pdf --start 3 --end 5
python skills/pdf-open/scripts/pdf_cli.py split input.pdf output-pages/
python skills/pdf-open/scripts/pdf_cli.py rotate input.pdf rotated.pdf --degrees 90
python skills/pdf-open/scripts/pdf_cli.py render input.pdf previews/ --scale 1.6
python skills/pdf-open/scripts/pdf_cli.py redact-text input.pdf redacted.pdf --text "Secret Phrase"
python skills/pdf-open/scripts/pdf_cli.py clean-metadata input.pdf cleaned.pdf
```

## Security & limitations

- Redaction is based on searchable text, and **cannot** promise removal of scanned pixels, embedded attachments, annotations, other string representations or undiscovered sensitive data. After redacting, perform visual and forensic review before public disclosure.
- A watermark is visible decoration, not a permissions/security control.
- Metadata minimization is not exhaustive digital-forensics sanitization.
- `from-text` deliberately supports ASCII only; for Chinese or other Unicode content, produce DOCX and render with LibreOffice using installed fonts.
- Encrypted PDFs are rejected rather than bypassed.

## Dependencies

`PyMuPDF>=1.24,<2`. See `references/pdf-quality.md`.
