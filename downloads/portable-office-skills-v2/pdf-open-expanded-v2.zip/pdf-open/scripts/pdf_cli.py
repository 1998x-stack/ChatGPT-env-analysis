#!/usr/bin/env python3
"""Original open PDF utilities based on the public PyMuPDF API."""
import argparse
import json
from pathlib import Path


def destination(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def open_pdf(path):
    import fitz
    doc = fitz.open(path)
    if doc.needs_pass:
        doc.close()
        raise ValueError(f"Password-protected PDF not supported: {path}")
    return doc


def inspect(args):
    with open_pdf(args.input) as doc:
        result = {"pages": len(doc), "page_sizes": [[round(p.rect.width, 2), round(p.rect.height, 2)] for p in doc], "encrypted": bool(doc.is_encrypted), "metadata": {k: v for k, v in (doc.metadata or {}).items() if k in ("title", "author", "subject") and v}, "contains_text": any(bool(p.get_text().strip()) for p in doc)}
        print(json.dumps(result, indent=2, ensure_ascii=False))


def extract(args):
    with open_pdf(args.input) as doc:
        lines = []
        for i, page in enumerate(doc, 1):
            if args.pages and i not in args.pages:
                continue
            lines.append(f"\n===== PAGE {i} =====\n{page.get_text(sort=True)}")
    result = "\n".join(lines).strip() + "\n"
    if args.output:
        Path(destination(args.output)).write_text(result, encoding="utf-8")
    else:
        print(result, end="")


def merge(args):
    import fitz
    out = fitz.open()
    try:
        for source in args.inputs:
            with open_pdf(source) as doc:
                out.insert_pdf(doc)
        if not out.page_count:
            raise ValueError("No input pages")
        out.save(destination(args.output), garbage=4, deflate=True)
    finally:
        out.close()
    print(f"Merged {len(args.inputs)} files into {args.output}")


def pages(args):
    import fitz
    with open_pdf(args.input) as doc:
        if not (1 <= args.start <= args.end <= len(doc)):
            raise ValueError(f"Page range 1..{len(doc)} required")
        out = fitz.open()
        try:
            out.insert_pdf(doc, from_page=args.start - 1, to_page=args.end - 1)
            out.save(destination(args.output), garbage=4, deflate=True)
        finally:
            out.close()
    print(f"Created {args.output}")


def split(args):
    import fitz
    folder = Path(args.outdir)
    folder.mkdir(parents=True, exist_ok=True)
    with open_pdf(args.input) as doc:
        count = len(doc)
        for i in range(count):
            out = fitz.open()
            try:
                out.insert_pdf(doc, from_page=i, to_page=i)
                out.save(folder / f"page-{i+1:04d}.pdf", deflate=True)
            finally:
                out.close()
    print(f"Split into {count} files in {folder}")


def rotate(args):
    with open_pdf(args.input) as doc:
        for page in doc:
            page.set_rotation((page.rotation + args.degrees) % 360)
        doc.save(destination(args.output), garbage=4, deflate=True)
    print(f"Rotated {args.output}")


def render(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    with open_pdf(args.input) as doc:
        for i, page in enumerate(doc, 1):
            if args.pages and i not in args.pages:
                continue
            pix = page.get_pixmap(matrix=__import__("fitz").Matrix(args.scale, args.scale), alpha=False)
            pix.save(outdir / f"page-{i:04d}.png")
    print(f"Rendered to {outdir}")


def watermark(args):
    import fitz
    with open_pdf(args.input) as doc:
        for page in doc:
            y = page.rect.y1 - 35
            page.insert_text((30, y), args.text, fontsize=10, color=(.45, .45, .45), overlay=True)
        doc.save(destination(args.output), garbage=4, deflate=True)
    print(f"Watermarked {args.output}; this is visible text, not document security")


def redact_text(args):
    import fitz
    phrase = args.text
    if len(phrase) < 2:
        raise ValueError("redaction phrase must have at least 2 characters")
    with open_pdf(args.input) as doc:
        count = 0
        for page in doc:
            matches = page.search_for(phrase)
            for rect in matches:
                page.add_redact_annot(rect, fill=(0, 0, 0))
                count += 1
            if matches:
                page.apply_redactions(images=2, graphics=1, text=0)
        if not count:
            raise ValueError("No matches found; output was not written")
        # Full rewrite + garbage collection to omit deleted content from new output.
        doc.save(destination(args.output), garbage=4, deflate=True, clean=True)
    # Independent text extraction validation for the exact phrase.
    with open_pdf(args.output) as verified:
        remaining = sum(len(page.search_for(phrase)) for page in verified)
    if remaining:
        raise ValueError(f"Verification failed: {remaining} searchable matches remain")
    print(f"Removed {count} matching text regions from {args.output}")
    print("Warning: visual redaction is not a full security audit; inspect rasterized pages, metadata, embedded files and OCR layers.")


def metadata_clean(args):
    with open_pdf(args.input) as doc:
        doc.set_metadata({})
        try:
            doc.del_xml_metadata()
        except (AttributeError, ValueError):
            pass
        doc.save(destination(args.output), garbage=4, deflate=True, clean=True)
    print(f"Wrote metadata-minimized {args.output}; not a full forensic sanitization")


def from_text(args):
    import fitz
    src = args.input.read_text(encoding="utf-8")
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    lines = src.splitlines()
    y = 55
    # Fixed-width drawing keeps this portable without relying on an external font.
    for line in lines:
        if y > 790:
            page = doc.new_page(width=595, height=842)
            y = 55
        if any(ord(c) > 127 for c in line):
            raise ValueError("from-text built-in font supports ASCII only; use DOCX + LibreOffice for CJK Unicode")
        page.insert_text((40, y), line[:105], fontsize=10)
        y += 14
    doc.save(destination(args.output), garbage=4, deflate=True)
    doc.close()
    print(f"Created {args.output}")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    p = sub.add_parser("inspect"); p.add_argument("input", type=Path); p.set_defaults(fn=inspect)
    p = sub.add_parser("text"); p.add_argument("input", type=Path); p.add_argument("--output", type=Path); p.add_argument("--pages", nargs="*", type=int); p.set_defaults(fn=extract)
    p = sub.add_parser("merge"); p.add_argument("output", type=Path); p.add_argument("inputs", type=Path, nargs="+"); p.set_defaults(fn=merge)
    p = sub.add_parser("pages"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.add_argument("--start", type=int, required=True); p.add_argument("--end", type=int, required=True); p.set_defaults(fn=pages)
    p = sub.add_parser("split"); p.add_argument("input", type=Path); p.add_argument("outdir", type=Path); p.set_defaults(fn=split)
    p = sub.add_parser("rotate"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.add_argument("--degrees", type=int, choices=[90, 180, 270], required=True); p.set_defaults(fn=rotate)
    p = sub.add_parser("render"); p.add_argument("input", type=Path); p.add_argument("outdir", type=Path); p.add_argument("--scale", type=float, default=1.5); p.add_argument("--pages", nargs="*", type=int); p.set_defaults(fn=render)
    p = sub.add_parser("watermark"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.add_argument("--text", required=True); p.set_defaults(fn=watermark)
    p = sub.add_parser("redact-text"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.add_argument("--text", required=True); p.set_defaults(fn=redact_text)
    p = sub.add_parser("clean-metadata"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.set_defaults(fn=metadata_clean)
    p = sub.add_parser("from-text"); p.add_argument("input", type=Path); p.add_argument("output", type=Path); p.set_defaults(fn=from_text)
    args = ap.parse_args()
    try:
        args.fn(args)
    except (ValueError, OSError, RuntimeError) as e:
        ap.exit(2, f"Error: {e}\n")

if __name__ == "__main__":
    main()
