# DOCX QA checklist

- Content: correct document title, headings, paragraphs, expected tables and images.
- Hierarchy: use actual Heading 1-4 styles (not only bold text).
- Layout: render to PDF with LibreOffice, verify page breaks, orphan headings, table boundaries, margins, and fonts.
- Accessibility: check meaningful captions, descriptive hyperlink text, linear reading order, logical table headers, and alternate image descriptions (this CLI does not automate image alt text).
- Privacy: do not rely on `scrub` alone for sensitive files. Comments, tracked changes, embedded objects and custom parts may remain.
- Fidelity: converting DOCX to PDF can alter pagination when fonts differ.
- Trust boundary: only load local user-provided input files; external resources are not fetched.
