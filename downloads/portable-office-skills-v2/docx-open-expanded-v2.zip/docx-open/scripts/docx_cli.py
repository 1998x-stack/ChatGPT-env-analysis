#!/usr/bin/env python3
"""Standalone DOCX workflows using public python-docx APIs. Original implementation."""
import argparse
import csv
import json
import shutil
import subprocess
from pathlib import Path


def parent(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_spec(path):
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("blocks"), list):
        raise ValueError('Expected JSON object with "blocks" array')
    return value


def apply_theme(document, theme):
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.section import WD_SECTION_START
    normal = document.styles["Normal"]
    normal.font.name = str(theme.get("font", "Calibri"))
    normal.font.size = Pt(float(theme.get("font_size", 10.5)))
    normal.paragraph_format.space_after = Pt(float(theme.get("space_after", 6)))
    margin = float(theme.get("margin_in", 0.8))
    if margin < .25 or margin > 3:
        raise ValueError("margin_in must be between .25 and 3")
    for section in document.sections:
        section.left_margin = section.right_margin = Inches(margin)
        section.top_margin = section.bottom_margin = Inches(margin)
    for level in range(1, 5):
        sty = document.styles[f"Heading {level}"]
        sty.font.name = normal.font.name
        sty.font.color.rgb = RGBColor.from_string(str(theme.get("heading_color", "203A59")).lstrip("#"))
        sty.font.size = Pt(max(12, 21 - level * 2))


def build_block(document, block, base):
    from docx.shared import Inches
    from docx.enum.table import WD_TABLE_ALIGNMENT
    typ = block.get("type", "paragraph")
    if typ == "paragraph":
        p = document.add_paragraph(str(block.get("text", "")))
        if block.get("bold"):
            for run in p.runs:
                run.bold = True
    elif typ == "heading":
        level = int(block.get("level", 1))
        if not 1 <= level <= 4:
            raise ValueError("heading level must be 1..4")
        document.add_heading(str(block.get("text", "")), level=level)
    elif typ in ("bullets", "numbered"):
        items = block.get("items", [])
        if not isinstance(items, list):
            raise ValueError("items must be an array")
        for entry in items:
            document.add_paragraph(str(entry), style="List Bullet" if typ == "bullets" else "List Number")
    elif typ == "table":
        rows = block.get("rows", [])
        if not isinstance(rows, list) or not rows or not isinstance(rows[0], list):
            raise ValueError("table needs a nonempty rows array")
        cols = len(rows[0])
        if cols < 1 or any(not isinstance(row, list) or len(row) != cols for row in rows):
            raise ValueError("table rows must have equal width")
        t = document.add_table(rows=len(rows), cols=cols)
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ridx, row in enumerate(rows):
            for cidx, value in enumerate(row):
                cell = t.cell(ridx, cidx)
                cell.text = str(value)
                if ridx == 0 and block.get("header", True):
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.bold = True
    elif typ == "image":
        image = (base / str(block.get("path", ""))).resolve()
        if not image.is_file():
            raise ValueError(f"Image does not exist: {image}")
        width = float(block.get("width_in", 5.5))
        if not .1 <= width <= 8.5:
            raise ValueError("image width must be between 0.1 and 8.5 inches")
        document.add_picture(str(image), width=Inches(width))
        if block.get("caption"):
            document.add_paragraph(str(block["caption"]), style="Caption")
    elif typ == "pagebreak":
        document.add_page_break()
    else:
        raise ValueError(f"Unsupported block type: {typ}")


def compose(args):
    from docx import Document
    spec = load_spec(args.input)
    doc = Document()
    title = str(spec.get("title", ""))
    doc.core_properties.title = title
    doc.core_properties.author = str(spec.get("author", ""))
    apply_theme(doc, spec.get("theme", {}))
    if title and spec.get("show_title", True):
        doc.add_heading(title, level=0)
    for blk in spec["blocks"]:
        if not isinstance(blk, dict):
            raise ValueError("Each block must be an object")
        build_block(doc, blk, args.input.parent)
    if spec.get("footer"):
        doc.sections[0].footer.paragraphs[0].text = str(spec["footer"])
    out = parent(args.output)
    doc.save(out)
    print(f"Created {out}: {len(doc.paragraphs)} paragraphs, {len(doc.tables)} tables")


def from_text(args):
    from docx import Document
    doc = Document()
    apply_theme(doc, {})
    if args.title:
        doc.core_properties.title = args.title
        doc.add_heading(args.title, level=0)
    for line in args.input.read_text(encoding="utf-8").splitlines():
        trimmed = line.strip()
        if not trimmed:
            continue
        if trimmed.startswith("### "):
            doc.add_heading(trimmed[4:], level=3)
        elif trimmed.startswith("## "):
            doc.add_heading(trimmed[3:], level=2)
        elif trimmed.startswith("# "):
            doc.add_heading(trimmed[2:], level=1)
        elif trimmed.startswith("- "):
            doc.add_paragraph(trimmed[2:], style="List Bullet")
        elif trimmed.startswith("1. "):
            doc.add_paragraph(trimmed[3:], style="List Number")
        else:
            doc.add_paragraph(trimmed)
    doc.save(parent(args.output))
    print(f"Created {args.output}")


def summarize(doc):
    from collections import Counter
    styles = Counter(p.style.name for p in doc.paragraphs)
    return {
        "paragraphs": len(doc.paragraphs),
        "tables": len(doc.tables),
        "sections": len(doc.sections),
        "inline_shapes": len(doc.inline_shapes),
        "styles": dict(styles),
        "title": doc.core_properties.title,
        "author_present": bool(doc.core_properties.author),
    }


def inspect(args):
    from docx import Document
    doc = Document(args.input)
    result = summarize(doc)
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(" | ".join(f"{k}: {v}" for k, v in result.items() if k != "styles"))


def extract(args):
    from docx import Document
    doc = Document(args.input)
    text = []
    for p in doc.paragraphs:
        if p.text.strip():
            style = p.style.name
            if style.startswith("Heading"):
                digits = "".join(c for c in style if c.isdigit())
                prefix = "#" * (int(digits) if digits else 1) + " "
            elif style == "List Bullet":
                prefix = "- "
            elif style == "List Number":
                prefix = "1. "
            else:
                prefix = ""
            text.append(prefix + p.text)
    for idx, table in enumerate(doc.tables, 1):
        text.append(f"\nTable {idx}")
        for row in table.rows:
            text.append("\t".join(c.text.replace("\n", " ") for c in row.cells))
    payload = "\n".join(text) + "\n"
    if args.output:
        parent(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload, end="")


def scrub(args):
    from docx import Document
    doc = Document(args.input)
    props = doc.core_properties
    for name in ("title", "subject", "author", "last_modified_by", "keywords", "comments", "category", "identifier", "content_status"):
        try:
            setattr(props, name, "")
        except (AttributeError, ValueError):
            pass
    doc.save(parent(args.output))
    print(f"Saved metadata-minimized file: {args.output}")
    print("Note: This is NOT a guarantee of removing comments, tracked changes, custom XML, or embedded metadata.")


def audit(args):
    from docx import Document
    d = Document(args.input)
    info = summarize(d)
    warnings = []
    if not any(p.style.name.startswith("Heading") for p in d.paragraphs):
        warnings.append("Document has no structured headings")
    if len(d.paragraphs) > 150 and len(d.sections) <= 1:
        warnings.append("Long document: review pagination and section breaks")
    if d.core_properties.author:
        warnings.append("Author metadata is present")
    if not d.paragraphs and not d.tables:
        warnings.append("Document is empty")
    print(json.dumps({"summary": info, "warnings": warnings}, ensure_ascii=False, indent=2))


def render(args):
    exe = shutil.which("libreoffice") or shutil.which("soffice")
    if exe is None:
        raise SystemExit("LibreOffice not found; install it for PDF rendering")
    out = args.output
    if out.suffix.lower() != ".pdf":
        raise SystemExit("render output must be .pdf")
    out.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run([exe, "-env:UserInstallation=file:///tmp/office-skills-lo", "--headless", "--convert-to", "pdf", "--outdir", str(out.parent), str(args.input)], capture_output=True, text=True, timeout=75)
    actual = out.parent / (args.input.stem + ".pdf")
    if result.returncode or not actual.exists():
        raise SystemExit("LibreOffice conversion failed: " + result.stderr[-500:])
    if actual != out:
        actual.replace(out)
    print(f"Rendered {out}; inspect each page for fidelity")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("compose", help="Create structured DOCX from JSON spec")
    a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=compose)
    a = sub.add_parser("from-text", help="Create from simple heading/list text")
    a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.add_argument("--title"); a.set_defaults(fn=from_text)
    a = sub.add_parser("inspect"); a.add_argument("input", type=Path); a.add_argument("--json", action="store_true"); a.set_defaults(fn=inspect)
    a = sub.add_parser("extract"); a.add_argument("input", type=Path); a.add_argument("--output", type=Path); a.set_defaults(fn=extract)
    a = sub.add_parser("scrub"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=scrub)
    a = sub.add_parser("audit"); a.add_argument("input", type=Path); a.set_defaults(fn=audit)
    a = sub.add_parser("render"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=render)
    args = p.parse_args()
    try:
        args.fn(args)
    except (ValueError, OSError) as e:
        p.exit(2, f"Error: {e}\n")

if __name__ == "__main__":
    main()
