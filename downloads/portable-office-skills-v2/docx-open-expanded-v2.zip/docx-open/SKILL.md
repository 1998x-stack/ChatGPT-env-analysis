---
name: docx-open
description: Independently authored DOCX workflow for structured writing, inspection, content extraction, basic metadata minimization, accessibility checks, and PDF conversion through installed LibreOffice.
---

# DOCX Open — Document Engineering

Use this Skill when creating or inspecting Word documents without access to proprietary platform templates. Operates on files supplied by the user or generated from original structured specifications. **It is not a copy of, or feature-equivalent replacement for, any internal OpenAI Skill.**

## Decision flow

1. Decide whether the input is a structured JSON brief (`compose`) or restricted lightweight text (`from-text`). Complex arbitrary Markdown is **not** supported.
2. Generate editable DOCX via `python-docx`.
3. Inspect structure and run `audit` (headings, author metadata, long document warnings).
4. Optionally render with LibreOffice and **visually inspect every page** for pagination, tables, fonts, overflow.
5. Export with stable filename and report anything not verified.

## CLI

```bash
python skills/docx-open/scripts/docx_cli.py compose examples/docx-report.json output/report.docx
python skills/docx-open/scripts/docx_cli.py from-text notes.md output/notes.docx --title "Notes"
python skills/docx-open/scripts/docx_cli.py inspect output/report.docx --json
python skills/docx-open/scripts/docx_cli.py extract output/report.docx --output output/content.txt
python skills/docx-open/scripts/docx_cli.py audit output/report.docx
python skills/docx-open/scripts/docx_cli.py render output/report.docx output/report.pdf
python skills/docx-open/scripts/docx_cli.py scrub output/report.docx output/report-minimal-metadata.docx
```

## Specification

`examples/docx-report.json`: `title`, `author`, `footer`, optional `theme` (`font`, `font_size`, `margin_in`, `heading_color`), and `blocks` array. Supported blocks: `paragraph`, `heading` (level 1–4), `bullets`, `numbered`, `table` (rectangular `rows`), `image` (`path`, `width_in`, `caption`), `pagebreak`.

## Quality & security gates

- Use a separate output filename; never overwrite the source as part of a scrub or render.
- `scrub` only clears common core properties. It is **not** full removal of comments, revision history, custom XML or embedded metadata. Inspect OOXML or use another dedicated privacy process for sensitive documents.
- Do not equate a successful DOCX save with visual fidelity; perform render and page inspection.
- Refer to `references/docx-quality.md` for the QA checklist.

## Requirements

`python-docx>=1.1,<2`; optional LibreOffice. All commands run locally and make no network calls.
