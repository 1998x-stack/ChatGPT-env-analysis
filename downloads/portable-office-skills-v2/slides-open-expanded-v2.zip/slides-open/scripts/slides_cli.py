#!/usr/bin/env python3
"""Portable presentation builder from a documented JSON specification."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess


def rgb(value):
    from pptx.dml.color import RGBColor
    s = str(value).strip().lstrip("#")
    if len(s) != 6:
        raise ValueError("Color must be a 6-digit hex RGB string")
    return RGBColor.from_string(s.upper())


def text_box(slide, x, y, w, h, text, *, font=20, color="233044", bold=False, align=None):
    from pptx.util import Inches, Pt
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = shape.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(.07)
    tf.margin_right = Inches(.07)
    tf.text = str(text)
    for p in tf.paragraphs:
        p.font.size = Pt(font)
        p.font.bold = bold
        p.font.color.rgb = rgb(color)
        if align is not None:
            p.alignment = align
    return shape


def add_background(slide, theme):
    from pptx.dml.color import RGBColor
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb(theme.get("background", "FFFFFF"))


def add_header(slide, title, theme):
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.util import Inches
    text_box(slide, .62, .4, 12, .7, title, font=30, color=theme.get("foreground", "243447"), bold=True)
    strip = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.68), Inches(1.27), Inches(1.2), Inches(.065))
    strip.fill.solid()
    strip.fill.fore_color.rgb = rgb(theme.get("accent", "0B8F82"))
    strip.line.fill.background()


def add_bullets(slide, items, x, y, width, theme, font=23):
    if not isinstance(items, list):
        raise ValueError("bullets must be an array")
    if len(items) > 10:
        raise ValueError("Too many bullet items; split into more slides")
    vertical = y
    for line in items:
        text_box(slide, x, vertical, width, .55, "•  " + str(line), font=font, color=theme.get("foreground", "243447"))
        vertical += .58


def add_table(slide, rows, theme):
    from pptx.util import Inches, Pt
    if not rows or not isinstance(rows[0], list):
        raise ValueError("table.rows must be a nonempty 2D array")
    nc = len(rows[0]); nr = len(rows)
    if not 1 <= nc <= 8 or not 1 <= nr <= 16 or any(len(row) != nc for row in rows):
        raise ValueError("table rows must be rectangular, max 16 rows x 8 columns")
    graphic = slide.shapes.add_table(nr, nc, Inches(.7), Inches(1.55), Inches(11.9), Inches(min(5.4, nr * .42)))
    t = graphic.table
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = str(val)
            if i == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = rgb(theme.get("accent", "0B8F82"))
            for paragraph in cell.text_frame.paragraphs:
                paragraph.font.size = Pt(16)
                paragraph.font.bold = i == 0
                paragraph.font.color.rgb = rgb("FFFFFF" if i == 0 else theme.get("foreground", "243447"))


def add_chart(slide, chart, theme):
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    from pptx.util import Inches
    cats = chart.get("categories", [])
    values = chart.get("values", [])
    if not cats or len(cats) != len(values) or len(cats) > 25:
        raise ValueError("chart categories/values must have matching length 1..25")
    if any(not isinstance(n, (int, float)) or isinstance(n, bool) for n in values):
        raise ValueError("chart values must be numbers")
    data = CategoryChartData()
    data.categories = [str(x) for x in cats]
    data.add_series(str(chart.get("label", "Value")), values)
    kind = {"bar": XL_CHART_TYPE.COLUMN_CLUSTERED, "line": XL_CHART_TYPE.LINE, "horizontal": XL_CHART_TYPE.BAR_CLUSTERED}.get(chart.get("type", "bar"))
    if kind is None:
        raise ValueError("chart type must be bar, line, or horizontal")
    graphic = slide.shapes.add_chart(kind, Inches(1.0), Inches(1.55), Inches(11.5), Inches(5.2), data)
    graphic.chart.has_legend = False
    graphic.chart.has_title = bool(chart.get("title"))
    if chart.get("title"):
        graphic.chart.chart_title.text_frame.text = str(chart["title"])


def create(args):
    from pptx import Presentation
    from pptx.util import Inches
    spec = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(spec, dict) or not isinstance(spec.get("slides"), list):
        raise ValueError('Expected JSON object with "slides" array')
    theme = spec.get("theme") or {}
    deck = Presentation()
    deck.slide_width, deck.slide_height = Inches(13.333), Inches(7.5)
    deck.core_properties.title = str(spec.get("title", ""))
    for n, item in enumerate(spec["slides"], 1):
        if not isinstance(item, dict):
            raise ValueError("Each slide must be a JSON object")
        slide = deck.slides.add_slide(deck.slide_layouts[6])
        add_background(slide, theme)
        layout = item.get("layout", "bullets")
        if layout == "title":
            text_box(slide, .8, 1.7, 11.7, 1.3, item.get("title", ""), font=48, bold=True, color=theme.get("foreground", "243447"))
            text_box(slide, .84, 3.25, 11.3, 1, item.get("subtitle", ""), font=24, color=theme.get("accent", "0B8F82"))
        elif layout == "bullets":
            add_header(slide, str(item.get("title", "")), theme)
            add_bullets(slide, item.get("bullets", []), .8, 1.65, 11.6, theme)
        elif layout == "two_columns":
            add_header(slide, str(item.get("title", "")), theme)
            if item.get("left_title"):
                text_box(slide, .78, 1.53, 5.8, .5, item["left_title"], font=22, bold=True)
            if item.get("right_title"):
                text_box(slide, 7.0, 1.53, 5.5, .5, item["right_title"], font=22, bold=True)
            add_bullets(slide, item.get("left", []), .8, 2.12, 5.5, theme, font=20)
            add_bullets(slide, item.get("right", []), 7.0, 2.12, 5.5, theme, font=20)
        elif layout == "table":
            add_header(slide, str(item.get("title", "")), theme)
            add_table(slide, item.get("rows", []), theme)
        elif layout == "chart":
            add_header(slide, str(item.get("title", "")), theme)
            add_chart(slide, item.get("chart", {}), theme)
        elif layout == "image":
            add_header(slide, str(item.get("title", "")), theme)
            photo = (args.input.parent / str(item.get("path", ""))).resolve()
            if not photo.is_file():
                raise ValueError(f"Image not found: {photo}")
            slide.shapes.add_picture(str(photo), Inches(.8), Inches(1.5), width=Inches(min(11.7, float(item.get("width_in", 9.5)))))
            if item.get("caption"):
                text_box(slide, .8, 6.73, 11.8, .4, item["caption"], font=13, color=theme.get("foreground", "243447"))
        else:
            raise ValueError(f"Unsupported layout {layout} on slide {n}")
        if item.get("notes"):
            slide.notes_slide.notes_text_frame.text = str(item["notes"])
        text_box(slide, 12.35, 7.05, .5, .25, str(n), font=10, color=theme.get("foreground", "243447"))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    deck.save(args.output)
    print(f"Created {args.output} with {len(deck.slides)} slides")


def inspect(args):
    from pptx import Presentation
    deck = Presentation(args.input)
    slides = []
    for i, slide in enumerate(deck.slides, 1):
        items = []
        for shape in slide.shapes:
            if shape.has_text_frame and shape.text.strip():
                items.append(shape.text.strip())
        slides.append({"index": i, "shape_count": len(slide.shapes), "text": items})
    info = {"slides": len(deck.slides), "dimensions_emu": [deck.slide_width, deck.slide_height], "items": slides}
    if args.json:
        print(json.dumps(info, indent=2, ensure_ascii=False))
    else:
        for x in info["items"]:
            print(f"{x['index']}. {x['text'][0][:100] if x['text'] else '(no title)'}")


def audit(args):
    from pptx import Presentation
    deck = Presentation(args.input)
    issues = []
    for n, slide in enumerate(deck.slides, 1):
        for shape in slide.shapes:
            if shape.left < 0 or shape.top < 0 or shape.left + shape.width > deck.slide_width or shape.top + shape.height > deck.slide_height:
                issues.append({"slide": n, "issue": "shape outside canvas", "shape": shape.name})
        if len(slide.shapes) > 100:
            issues.append({"slide": n, "issue": "very dense slide"})
    print(json.dumps({"slides": len(deck.slides), "issues": issues, "note": "Layout check is geometric only; always review rendered slides"}, ensure_ascii=False, indent=2))


def render(args):
    exe = shutil.which("libreoffice") or shutil.which("soffice")
    if not exe:
        raise ValueError("LibreOffice is required for PDF conversion")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([exe, "-env:UserInstallation=file:///tmp/office-skills-slides-lo", "--headless", "--convert-to", "pdf", "--outdir", str(args.output.parent), str(args.input)], capture_output=True, text=True, timeout=75)
    actual = args.output.parent / (args.input.stem + ".pdf")
    if r.returncode or not actual.exists():
        raise ValueError(f"LibreOffice failed: {r.stderr[-300:]}")
    if actual != args.output:
        actual.replace(args.output)
    print(f"Created {args.output}; visually inspect each slide")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("create"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=create)
    a = sub.add_parser("inspect"); a.add_argument("input", type=Path); a.add_argument("--json", action="store_true"); a.set_defaults(fn=inspect)
    a = sub.add_parser("audit"); a.add_argument("input", type=Path); a.set_defaults(fn=audit)
    a = sub.add_parser("render"); a.add_argument("input", type=Path); a.add_argument("output", type=Path); a.set_defaults(fn=render)
    args = p.parse_args()
    try:
        args.fn(args)
    except (ValueError, OSError) as e:
        p.exit(2, f"Error: {e}\n")

if __name__ == "__main__":
    main()
