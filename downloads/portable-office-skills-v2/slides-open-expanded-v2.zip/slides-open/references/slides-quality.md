# Slides QA checklist

1. Message: each slide must have a unique central point; remove redundant bullets.
2. Source data: chart labels, units, and values must be grounded in user data; never invent numbers.
3. Readability: title ~30pt, body 20-24pt, dense tables may need multiple slides.
4. Geometry: run `audit`, then render and inspect all slides; bounds checks alone cannot detect clipped text.
5. Portability: images are embedded; fonts may substitute on other machines; validate on target office software.
6. Accessibility: supply meaningful alt text manually if used beyond internal review; script currently does not populate alt descriptions.
7. Privacy: notes and embedded assets may carry sensitive data; review prior to publication.
