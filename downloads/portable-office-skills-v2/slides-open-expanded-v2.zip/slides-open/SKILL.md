---
name: slides-open
description: Original slides workflow to create editable 16:9 PPTX decks from JSON with title, bullet, two-column, image, table, and bar/line charts; inspect, audit geometry, and render using LibreOffice.
---

# Slides Open — Presentation Engineering

Use to build **editable PPTX** from a controlled specification. The JSON source is the canonical input. Do not claim visual parity with other platform's internal presentation engines.

## Authoring workflow

1. Define audience, message, slide sequence and source-of-truth numbers.
2. Prepare JSON in the format of `examples/slides-deck.json`.
3. Choose layouts: `title`, `bullets`, `two_columns`, `image`, `table`, or `chart` (`bar`, `line`, `horizontal`).
4. Generate PPTX, audit geometric bounds, render to PDF if LibreOffice is available, and visually inspect each slide.
5. Revise dense or overflow-prone slides in the JSON source rather than hand-patching output.

## Commands

```bash
python skills/slides-open/scripts/slides_cli.py create examples/slides-deck.json output/deck.pptx
python skills/slides-open/scripts/slides_cli.py inspect output/deck.pptx --json
python skills/slides-open/scripts/slides_cli.py audit output/deck.pptx
python skills/slides-open/scripts/slides_cli.py render output/deck.pptx output/deck.pdf
```

## Source schema

Top-level: `title`, optional `theme` (`background`, `foreground`, `accent`: hex RGB), `slides` array.

- `title`: title, subtitle.
- `bullets`: title and bullets array.
- `two_columns`: title, left_title, right_title, left array, right array.
- `table`: title, `rows` rectangular list, max 16 rows × 8 columns.
- `chart`: title, chart object with type, categories, values, optional label/title.
- `image`: title, image `path` relative to spec, `width_in`, caption.
- `notes` string may be provided per slide. All slides are 16:9.

## QA gates

`audit` detects shapes outside slide boundaries but not every possible text overflow. Perform a visual QA pass. Keep citations/attribution in the deck content where needed. Refer to `references/slides-quality.md`.

## Dependencies

`python-pptx>=1,<2`; optional LibreOffice.
