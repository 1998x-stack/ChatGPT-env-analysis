"""Real local format-level regression tests for the independent office skills."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args, check=True):
    return subprocess.run([sys.executable, *map(str, args)], text=True, capture_output=True, check=check)


class PortableSkillsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = Path(self.tmp.name)

    def cli(self, skill, script, *args, check=True):
        return run(ROOT / "skills" / skill / "scripts" / script, *args, check=check)

    def test_docx_compose_extract_audit(self):
        from docx import Document
        dest = self.p / "report.docx"
        self.cli("docx-open", "docx_cli.py", "compose", ROOT / "examples/docx-report.json", dest)
        doc = Document(dest)
        self.assertGreaterEqual(len(doc.tables), 1)
        self.assertEqual(doc.core_properties.title, "Portable Office Skills: Sample Report")
        audit = json.loads(self.cli("docx-open", "docx_cli.py", "audit", dest).stdout)
        self.assertGreater(audit["summary"]["paragraphs"], 5)
        extracted = self.cli("docx-open", "docx_cli.py", "extract", dest).stdout
        self.assertIn("Executive summary", extracted)
        self.assertIn("Capability", extracted)

    def test_docx_scrub_and_text(self):
        from docx import Document
        source = self.p / "notes.docx"
        self.cli("docx-open", "docx_cli.py", "from-text", ROOT / "examples/notes.md", source, "--title", "Notes")
        output = self.p / "clean.docx"
        self.cli("docx-open", "docx_cli.py", "scrub", source, output)
        self.assertEqual(Document(output).core_properties.title, "")
        self.assertTrue(any(p.style.name.startswith("Heading") for p in Document(output).paragraphs))

    def _pdf_with_text(self, word="Confidential Example"):
        import fitz
        src = self.p / "source.pdf"
        doc = fitz.open()
        page = doc.new_page(width=595, height=842)
        page.insert_text((60, 80), word, fontsize=14)
        doc.save(src)
        doc.close()
        return src

    def test_pdf_merge_split_render(self):
        import fitz
        src = self._pdf_with_text()
        merged = self.p / "merged.pdf"
        self.cli("pdf-open", "pdf_cli.py", "merge", merged, src, src)
        with fitz.open(merged) as doc:
            self.assertEqual(len(doc), 2)
        split = self.p / "split"
        self.cli("pdf-open", "pdf_cli.py", "split", merged, split)
        self.assertEqual(len(list(split.glob("*.pdf"))), 2)
        self.cli("pdf-open", "pdf_cli.py", "render", src, self.p / "renders", "--scale", "1")
        self.assertTrue((self.p / "renders/page-0001.png").is_file())
        self.cli("pdf-open", "pdf_cli.py", "pages", merged, self.p / "one.pdf", "--start", "1", "--end", "1")
        self.cli("pdf-open", "pdf_cli.py", "rotate", src, self.p / "rotate.pdf", "--degrees", "90")
        with fitz.open(self.p / "rotate.pdf") as doc:
            self.assertEqual(doc[0].rotation, 90)

    def test_pdf_redaction_is_real_text_removal(self):
        import fitz
        src = self._pdf_with_text("Highly Sensitive")
        out = self.p / "redacted.pdf"
        self.cli("pdf-open", "pdf_cli.py", "redact-text", src, out, "--text", "Highly Sensitive")
        with fitz.open(out) as doc:
            self.assertEqual(len(doc[0].search_for("Highly Sensitive")), 0)
            self.assertNotIn("Highly Sensitive", doc[0].get_text())
        # No-match is an error and produces no output.
        r = self.cli("pdf-open", "pdf_cli.py", "redact-text", src, self.p / "none.pdf", "--text", "Unknown Phrase", check=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse((self.p / "none.pdf").exists())

    def test_pdf_text_inspect(self):
        src = self._pdf_with_text("Audit token")
        info = json.loads(self.cli("pdf-open", "pdf_cli.py", "inspect", src).stdout)
        self.assertEqual(info["pages"], 1)
        self.assertIn("Audit token", self.cli("pdf-open", "pdf_cli.py", "text", src).stdout)

    def test_slides_create_audit(self):
        from pptx import Presentation
        dest = self.p / "deck.pptx"
        self.cli("slides-open", "slides_cli.py", "create", ROOT / "examples/slides-deck.json", dest)
        ppt = Presentation(dest)
        self.assertEqual(len(ppt.slides), 5)
        self.assertTrue(any(getattr(s, "has_chart", False) for slide in ppt.slides for s in slide.shapes))
        info = json.loads(self.cli("slides-open", "slides_cli.py", "audit", dest).stdout)
        self.assertEqual(info["slides"], 5)
        self.assertEqual(info["issues"], [])
        described = json.loads(self.cli("slides-open", "slides_cli.py", "inspect", dest, "--json").stdout)
        self.assertEqual(described["slides"], 5)

    def test_spreadsheets_build_formula_chart(self):
        from openpyxl import load_workbook
        dest = self.p / "model.xlsx"
        self.cli("spreadsheets-open", "sheets_cli.py", "build", ROOT / "examples/workbook.json", dest)
        book = load_workbook(dest)
        self.assertEqual(len(book.sheetnames), 2)
        self.assertEqual(book["Revenue"]["D2"].value, "=B2*C2")
        self.assertEqual(len(book["Revenue"]._charts), 1)
        info = json.loads(self.cli("spreadsheets-open", "sheets_cli.py", "audit", dest).stdout)
        self.assertEqual(info["formulas"], 3)
        self.cli("spreadsheets-open", "sheets_cli.py", "export-csv", dest, self.p / "data.csv", "--sheet", "Revenue")
        self.assertTrue((self.p / "data.csv").exists())
        book.close()

    def test_csv_formula_injection_sanitized(self):
        from openpyxl import load_workbook
        input_path = self.p / "source.csv"
        input_path.write_text("Name,Value\nX,=1+1\nY,@EVAL\n", encoding="utf-8")
        dest = self.p / "safe.xlsx"
        self.cli("spreadsheets-open", "sheets_cli.py", "import-csv", input_path, dest)
        wb = load_workbook(dest)
        self.assertNotEqual(wb.active["B2"].data_type, "f")
        self.assertTrue(wb.active["B2"].value.startswith("'="))
        self.assertTrue(wb.active["B3"].value.startswith("'@"))
        wb.close()

    def test_spreadsheets_compare(self):
        a = self.p / "a.csv"; b = self.p / "b.csv"
        a.write_text("A,B\n1,2\n"); b.write_text("A,B\n1,9\n")
        self.cli("spreadsheets-open", "sheets_cli.py", "import-csv", a, self.p / "a.xlsx")
        self.cli("spreadsheets-open", "sheets_cli.py", "import-csv", b, self.p / "b.xlsx")
        result = json.loads(self.cli("spreadsheets-open", "sheets_cli.py", "compare", self.p / "a.xlsx", self.p / "b.xlsx").stdout)
        self.assertEqual(result["changed_cells"][0]["cell"], "B2")

    def test_install_dry_run_backup(self):
        project = self.p / "project"
        dry = run(ROOT / "install.py", "--framework", "all", "--project", project, "--dry-run")
        self.assertIn("DRY RUN", dry.stdout)
        self.assertFalse((project / ".codex").exists())
        run(ROOT / "install.py", "--framework", "codex", "--project", project)
        expected = project / ".codex/skills/docx-open/SKILL.md"
        self.assertTrue(expected.exists())
        run(ROOT / "install.py", "--framework", "codex", "--project", project, "--force")
        self.assertTrue((project / ".codex/skills/docx-open.backup-001/SKILL.md").exists())

    def test_root_package_features(self):
        for name in ("docx", "pdf", "slides", "spreadsheets"):
            self.assertTrue((ROOT / "skills" / f"{name}-open" / "SKILL.md").exists())
            self.assertGreater(len((ROOT / "skills" / f"{name}-open" / "SKILL.md").read_text()), 1000)
        self.assertIn("未实现", (ROOT / "docs/FEATURE-MATRIX.zh-CN.md").read_text())


if __name__ == "__main__":
    unittest.main()
