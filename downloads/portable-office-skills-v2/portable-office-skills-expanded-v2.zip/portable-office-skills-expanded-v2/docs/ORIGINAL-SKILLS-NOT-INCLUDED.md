# Platform Skill licensing boundary

The platform-hosted skill directories observed in this session were:

| Platform source path | Approx. size during audit | Included in this archive? |
|---|---:|---|
| `/home/oai/skills/docx` | 492 KiB | **No** |
| `/home/oai/skills/pdfs` | 308 KiB | **No** |
| `/home/oai/skills/slides` | 123 MiB | **No** |
| `/home/oai/skills/spreadsheets` | 40 KiB | **No** |

All four have a `LICENSE.txt` stating, among other restrictions, that users may not extract the materials from the Services, retain copies outside Services, reproduce or distribute them, or reverse engineer them. This archive is therefore a separately-authored alternative, not a proprietary source backup. The actual licenses govern the original files. No third-party source material was copied into this distribution.
