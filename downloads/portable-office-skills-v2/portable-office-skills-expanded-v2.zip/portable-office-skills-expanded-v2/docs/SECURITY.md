# Local Security Model

- All commands operate on local files. No built-in code deliberately performs network requests or fetches remote URLs.
- The installer writes only to user-selected directories and will not overwrite without `--force`; forced operations create numbered backups.
- Source JSON files are considered user-controlled input. Formula mappings in spreadsheet JSON are executable workbook formulas and must come from trusted authors.
- CSV-imported strings resembling formulas are escaped. The rule is a risk reduction, not comprehensive security against every spreadsheet application.
- Be cautious with malicious DOCX, PDF, PPTX and XLSX files. The underlying parsing libraries may have vulnerabilities; isolate untrusted inputs and keep dependencies patched.
- Redaction is not a guarantee of forensic privacy. Review hidden layers, rasterized images, attachments, metadata and copies before public sharing.
- Do not distribute secrets, third-party copyrighted materials, or proprietary platform Skill files inside the archive.
- Dependency version constraints are deliberately broad within major versions and are not a reproducible lockfile; use a lockfile and hash-pinned wheels in higher-assurance environments.
