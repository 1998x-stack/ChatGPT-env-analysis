# Example Notes

## Scope

This is sample text for DOCX conversion.

- Create document
- Check headings
- Visually inspect output
