#!/usr/bin/env python3
"""Verify all source files against a checked-in SHA-256 manifest."""
import hashlib
import sys
from pathlib import Path

def main():
    root=Path(__file__).resolve().parent
    manifest=root/'MANIFEST.sha256'
    missing=[];changed=[];seen=set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        digest,relative=line.split('  ',1)
        path=root/relative
        seen.add(relative)
        if not path.is_file():missing.append(relative)
        elif hashlib.sha256(path.read_bytes()).hexdigest()!=digest:changed.append(relative)
    extra=[p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256' and not any(part in ('__pycache__','.venv') for part in p.parts) and p.relative_to(root).as_posix() not in seen]
    print(f'Checked: {len(seen)}; missing={len(missing)}; changed={len(changed)}; extra={len(extra)}')
    for label,items in [('MISSING',missing),('CHANGED',changed),('EXTRA',extra)]:
        for item in items:print(label,item)
    return int(bool(missing or changed or extra))
if __name__=='__main__':sys.exit(main())
