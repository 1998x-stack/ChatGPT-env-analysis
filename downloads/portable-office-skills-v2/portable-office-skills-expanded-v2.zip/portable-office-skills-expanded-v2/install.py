#!/usr/bin/env python3
"""Install the original portable skills in a user-controlled destination.

Never accesses OpenAI's platform skills directory.
"""
import argparse
import shutil
import sys
from pathlib import Path

SKILLS = ('docx-open', 'pdf-open', 'slides-open', 'spreadsheets-open')
TARGETS = {
    'codex': '.codex/skills',
    'claude': '.claude/skills',
    'opencode': '.opencode/skills',
    'pi': '.pi/skills',
}

def main():
    ap=argparse.ArgumentParser(description='Install portable, independently authored office skills')
    ap.add_argument('--framework', choices=(*TARGETS, 'all'), default='codex')
    ap.add_argument('--project', type=Path, default=Path.cwd(), help='Project root, default current directory')
    ap.add_argument('--dest', type=Path, help='Explicit skills destination; incompatible with --framework all')
    ap.add_argument('--skills', nargs='+', choices=SKILLS, default=list(SKILLS))
    ap.add_argument('--force', action='store_true', help='Replace existing target after a backup')
    ap.add_argument('--dry-run', action='store_true')
    args=ap.parse_args()
    if args.dest and args.framework=='all': ap.error('--dest cannot be combined with --framework all')
    root=Path(__file__).resolve().parent
    destinations=[args.dest] if args.dest else [args.project / TARGETS[k] for k in (TARGETS if args.framework=='all' else [args.framework])]
    plan=[]
    for dest in destinations:
        for name in args.skills:
            src=root/'skills'/name; dst=dest.expanduser().resolve()/name
            if not (src/'SKILL.md').is_file(): raise SystemExit(f'Missing source SKILL.md: {src}')
            plan.append((src,dst))
    for src,dst in plan:
        if dst.exists() and not args.force:
            print(f'SKIP: {dst} exists (pass --force for backup and replacement)')
            continue
        if args.dry_run:
            print(f'DRY RUN: {src} -> {dst}')
            continue
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():
            suffix=1
            while True:
                backup=dst.with_name(dst.name+f'.backup-{suffix:03d}')
                if not backup.exists(): break
                suffix+=1
            shutil.move(str(dst),str(backup))
            print(f'BACKUP: {dst} -> {backup}')
        shutil.copytree(src,dst)
        print(f'INSTALLED: {dst}')
    print('Done. Dependencies must be installed separately into a virtual environment.')
    return 0
if __name__=='__main__': sys.exit(main())
