# Portable Office Skills — Expanded v2

**四套重新独立实现、可在本地安装和扩展的 Office Skills。**

> 此项目不是 `/home/oai/skills` 中 OpenAI 专有 Skill 的复制、镜像、导出包或功能等价承诺。OpenAI 内置四套 Skill 的 LICENSE.txt 明确限制提取和再分发；因此本包不包含它们的任何代码、提示词、模板或资源。

## 包含内容

| Skill | 入口 | 主要操作 |
|---|---|---|
| `docx-open` | `skills/docx-open/scripts/docx_cli.py` | `compose`, `from-text`, `inspect`, `extract`, `scrub`, `audit`, `render` |
| `pdf-open` | `skills/pdf-open/scripts/pdf_cli.py` | `inspect`, `text`, `merge`, `pages`, `split`, `rotate`, `render`, `watermark`, `redact-text`, `clean-metadata`, `from-text` |
| `slides-open` | `skills/slides-open/scripts/slides_cli.py` | `create`, `inspect`, `audit`, `render` |
| `spreadsheets-open` | `skills/spreadsheets-open/scripts/sheets_cli.py` | `import-csv`, `build`, `inspect`, `export-csv`, `audit`, `compare` |

**合计 28 个子命令**，另附 JSON 输入示例、6 类结构化分析/参考文档、安装和升级说明、回归测试、SHA-256 清单。所有编写内容采用本包 MIT 许可。

## 安装

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python install.py --framework all --project /path/to/project --dry-run
python install.py --framework all --project /path/to/project
python -m unittest discover -s tests -v
python verify.py
```

`install.py` 支持 `.codex/skills`, `.claude/skills`, `.opencode/skills`, `.pi/skills`。默认不覆盖已有 Skill；`--force` 会先备份。可使用 `--dest` 指向自定义目录。

## 快速验证

```bash
mkdir -p output
python skills/docx-open/scripts/docx_cli.py compose examples/docx-report.json output/example.docx
python skills/pdf-open/scripts/pdf_cli.py inspect output/example.pdf  # 请先准备一个 PDF
python skills/slides-open/scripts/slides_cli.py create examples/slides-deck.json output/example.pptx
python skills/spreadsheets-open/scripts/sheets_cli.py build examples/workbook.json output/example.xlsx
```

## 重要的限制

- DOCX 的元数据清理不是全面的隐私清洗；审阅痕迹和嵌入对象可能仍存在。
- PDF 文本脱敏仅适用于可搜索文本，不能保证对扫描页、嵌入文件或全部隐私元素安全。
- PPTX 几何审计不代替逐页渲染与视觉检查。
- XLSX `openpyxl` 不计算公式；须使用 Excel/LibreOffice 重算。
- PDF `from-text` 为可移植性只支持 ASCII；中文建议经 DOCX + LibreOffice。

## 资料

- [本地迁移指南](docs/MIGRATION.zh-CN.md)
- [功能覆盖矩阵](docs/FEATURE-MATRIX.zh-CN.md)
- [安全模型](docs/SECURITY.md)
- [版权边界](docs/PROVENANCE.md)
- [Skill 文件](skills/)

本包既适合独立 ZIP 迁移，也可以作为独立源码存储库。不要将此包误标为原始 OpenAI Skills。
